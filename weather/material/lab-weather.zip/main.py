CITIES_LIST = [
    "Bamberg",
    "Paris",
    "New York",
    "Tokyo",
    "Sydney",
    "Cape Town",
    "Rio de Janeiro",
    "Mumbai",
    "Dubai",
    "Toronto",
    "Shanghai",
    "Mexico City",
    "Bangkok",
    "Moscow",
    "Istanbul"
]


def fetch_weather(city_name):
    # TODO: implement this function as explained in the instructions 
    pass


def extract_data(weather):
    # TODO: implement this function as explained in the instructions 
    pass


if __name__ == "__main__":
    # TODO: implement the main logic as explained in the instructions
    pass
