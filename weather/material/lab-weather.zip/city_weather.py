class CityWeather:
    def __init__(self, city_name, condition, temperature, wind):
        self.city_name = city_name
        self.condition = condition
        self.temperature = temperature
        self.wind = wind
