#include <stdio.h>
#include <string.h>

menu_item menu[] = {
    {"Burger", 5.99},
    {"Pizza", 7.49},
    {"Salad", 4.99},
    {"Fries", 2.99},
    {"Soda", 1.99}
};

int menu_item_size = 5;

int main(void)
{

    return 0;
}
